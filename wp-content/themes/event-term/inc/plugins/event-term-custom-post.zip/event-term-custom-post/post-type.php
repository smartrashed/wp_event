<?php
/**
 * Plugin Name: Event Term Custom Post
 * Plugin URI: https://themeforest.net/user/codexcoder
 * Description: This plugin is for Event Term registration and custom post type
 * Author: CodexCoder
 * Author URI: http://codexcoder.com/
 * Version: 1.0.0
 * Text Domain: event-term-custom-post
 */


/*******************************************************************/
// testimonial post type
/*******************************************************************/

if ( !class_exists('Event_Term_Testimonial_Post_Type') ):

class Event_Term_Testimonial_Post_Type {
    public static $post_type = 'et_testimonial';
    public static $menu_position = 5; 
    public static $theme_text_domain = 'event-term-custom-post';
    public static function register() {
        // titles
        $labels = array(
                'name'                 => esc_html__('Testimonials',                 'event-term-custom-post'),
                'singular_name'        => esc_html__('Testimonials',                 'event-term-custom-post'),
                'add_new'              => esc_html__('Add New',                      'event-term-custom-post'),
                'add_new_item'         => esc_html__('Add New Testimonial',          'event-term-custom-post'),
                'edit_item'            => esc_html__('Edit Testimonial',             'event-term-custom-post'),
                'new_item'             => esc_html__('New Testimonial',              'event-term-custom-post'),
                'view_item'            => esc_html__('View Testimonial',             'event-term-custom-post'),
                'search_items'         => esc_html__('Search Testimonial',           'event-term-custom-post'),
                'not_found'            => esc_html__('No testimonial found',         'event-term-custom-post'),
                'not_found_in_trash'   => esc_html__('No testimonial found in trash','event-term-custom-post'), 
                'parent_item_colon'     => '',
                'menu_name'            => esc_html__('Testimonials', 'event-term-custom-post')
        );

        // options
        $args = array(
                'labels'                => $labels,
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true, 
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true, 
                'hierarchical'          => false,
                'menu_position'         => self::$menu_position,
                'menu_icon'             => 'dashicons-format-quote',
                'supports'              => array( 'title', 'editor' )
        );

        $args = apply_filters( 'presscore_post_type_' . self::$post_type . '_args', $args );

        register_post_type( self::$post_type, $args );
        flush_rewrite_rules();
        /* post type end */		
    }	
}
endif;

/*******************************************************************/
// Speakers post type
/*******************************************************************/

if ( !class_exists('Event_Term_Speakers_Post_Type') ):

class Event_Term_Speakers_Post_Type {
    public static $post_type = 'et_speakers';
    public static $menu_position = 5; 
    public static $theme_text_domain = 'event-term-custom-post';
    public static function register() {

        // titles
        $labels = array(
                'name'                 => esc_html__('Speakers',                  'event-term-custom-post'),
                'singular_name'        => esc_html__('Speakers',                  'event-term-custom-post'),
                'add_new'              => esc_html__('Add New',                   'event-term-custom-post'),
                'add_new_item'         => esc_html__('Add New Speakers',          'event-term-custom-post'),
                'edit_item'            => esc_html__('Edit Speakers',             'event-term-custom-post'),
                'new_item'             => esc_html__('New Speakers',              'event-term-custom-post'),
                'view_item'            => esc_html__('View Speakers',             'event-term-custom-post'),
                'search_items'         => esc_html__('Search Speakers',           'event-term-custom-post'),
                'not_found'            => esc_html__('No speakers found',         'event-term-custom-post'),
                'not_found_in_trash'   => esc_html__('No Speakers found in trash','event-term-custom-post'), 
                'parent_item_colon'     => '',
                'menu_name'            => esc_html__('Speakers', 'event-term-custom-post')
        );

        // options
        $args = array(
                'labels'                => $labels,
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true, 
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true, 
                'hierarchical'          => false,
                'menu_position'         => self::$menu_position,
                'menu_icon'             => 'dashicons-groups',
                'supports'              => array( 'title', 'editor', 'thumbnail' )
        );

        $args = apply_filters( 'presscore_post_type_' . self::$post_type . '_args', $args );

        register_post_type( self::$post_type, $args );
        flush_rewrite_rules();
        /* post type end */		
    }	
}

endif;

/*******************************************************************/
// Pricing table post type
/*******************************************************************/

if ( !class_exists('Event_Term_Pricing_Table_Post_Type') ):

class Event_Term_Pricing_Table_Post_Type {
    public static $post_type = 'et_pricing_table';
    public static $menu_position = 5; 
    public static $theme_text_domain = 'event-term-custom-post';
    public static function register() {

        // titles
        $labels = array(
                'name'                 => esc_html__('Pricing Table',                  'event-term-custom-post'),
                'singular_name'        => esc_html__('Pricing Tables',                 'event-term-custom-post'),
                'add_new'              => esc_html__('Add New',                        'event-term-custom-post'),
                'add_new_item'         => esc_html__('Add New Pricing Table',          'event-term-custom-post'),
                'edit_item'            => esc_html__('Edit Pricing Table',             'event-term-custom-post'),
                'new_item'             => esc_html__('New Pricing Table',              'event-term-custom-post'),
                'view_item'            => esc_html__('View Pricing Table',             'event-term-custom-post'),
                'search_items'         => esc_html__('Search Pricing Table',           'event-term-custom-post'),
                'not_found'            => esc_html__('No pricing table found',         'event-term-custom-post'),
                'not_found_in_trash'   => esc_html__('No pricing table found in trash','event-term-custom-post'), 
                'parent_item_colon'     => '',
                'menu_name'            => esc_html__('Pricing Table', 'event-term-custom-post')
        );

        // options
        $args = array(
                'labels'                => $labels,
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true, 
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true, 
                'hierarchical'          => false,
                'menu_position'         => self::$menu_position,
                'menu_icon'             => 'dashicons-networking',
                'supports'              => array( 'title' )
        );

        $args = apply_filters( 'presscore_post_type_' . self::$post_type . '_args', $args );

        register_post_type( self::$post_type, $args );
        flush_rewrite_rules();
            /* post type end */		
    }	
}
endif;

/*******************************************************************/
// Sponsors post type
/*******************************************************************/

if ( !class_exists('Event_Term_Sponsors_Post_Type') ):

class Event_Term_Sponsors_Post_Type {
    public static $post_type = 'et_sponsors';
    public static $menu_position = 5; 
    public static $theme_text_domain = 'event-term-custom-post';
    public static $taxonomy = 'et_sponsors_category';
    public static function register() {

        // titles
        $labels = array(
                'name'                 => esc_html__('Sponsors',                 'event-term-custom-post'),
                'singular_name'        => esc_html__('Sponsors',                 'event-term-custom-post'),
                'add_new'              => esc_html__('Add New',                  'event-term-custom-post'),
                'add_new_item'         => esc_html__('Add New Sponsor',          'event-term-custom-post'),
                'edit_item'            => esc_html__('Edit Sponsor',             'event-term-custom-post'),
                'new_item'             => esc_html__('New Sponsor',              'event-term-custom-post'),
                'view_item'            => esc_html__('View Sponsor',             'event-term-custom-post'),
                'search_items'         => esc_html__('Search Sponsor',           'event-term-custom-post'),
                'not_found'            => esc_html__('No sponsor found',         'event-term-custom-post'),
                'not_found_in_trash'   => esc_html__('No sponsor found in trash','event-term-custom-post'), 
                'parent_item_colon'     => '',
                'menu_name'            => esc_html__('Sponsors', 'event-term-custom-post')
        );

        // options
        $args = array(
                'labels'                => $labels,
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true, 
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true, 
                'hierarchical'          => false,
                'menu_position'         => self::$menu_position,
                'menu_icon'             => 'dashicons-format-quote',
                'supports'              => array( 'title', 'thumbnail' )
        );

        $args = apply_filters( 'presscore_post_type_' . self::$post_type . '_args', $args );

        register_post_type( self::$post_type, $args );
        flush_rewrite_rules();
        /* post type end */

        /* setup taxonomy */

        // titles
        $texanomy_labels = array(
                'name'             => esc_html__( 'Sponsor Categories',        'event-term-custom-post' ),
                'singular_name'    => esc_html__( 'Sponsor Category',          'event-term-custom-post' ),
                'all_items'        => esc_html__( 'Sponsor Categories',        'event-term-custom-post' ),
                'parent_item'      => esc_html__( 'Parent Sponsor Category',   'event-term-custom-post' ),
                'parent_item_colon'=> esc_html__( 'Parent Sponsor Category:',  'event-term-custom-post' ),
                'edit_item'        => esc_html__( 'Edit Category',             'event-term-custom-post' ), 
                'update_item'      => esc_html__( 'Update Category',           'event-term-custom-post' ),
                'add_new_item'     => esc_html__( 'Add New Sponsor Category',  'event-term-custom-post' ),
                'new_item_name'    => esc_html__( 'New Sponsor Name',          'event-term-custom-post' ),
                'menu_name'        => esc_html__( 'Sponsor Categories',        'event-term-custom-post' )
        );

        $taxonomy_args = array(
                'hierarchical'          => true,
                'public'                => true,
                'labels'                => $texanomy_labels,
                'show_ui'               => true,
                'rewrite'               => array('slug' => 'et_sponsors_category'),
                'show_admin_column'	=> true,
        );

        $taxonomy_args = apply_filters( 'presscore_taxonomy_' . self::$taxonomy . '_args', $taxonomy_args );

        register_taxonomy( self::$taxonomy, array( self::$post_type ), $taxonomy_args );
    }	
}
endif;

/////////////////////////
// Register post types //
/////////////////////////

if ( ! function_exists( 'event_term_register_post_types' ) ) :
    function event_term_register_post_types() {
        Event_Term_Testimonial_Post_Type::register();
        Event_Term_Speakers_Post_Type::register();
        Event_Term_Pricing_Table_Post_Type::register();
        Event_Term_Sponsors_Post_Type::register();
    }
endif;

add_action( 'init', 'event_term_register_post_types', 10 );